import QtQuick 2.0
import QtQuick.Layouts 1.1
import org.kde.plasma.core 2.0 as PlasmaCore

import org.kde.plasma.plasmoid 2.0
import org.kde.plasma.private.kicker 0.1 as Kicker
import org.kde.kcoreaddons 1.0 as KCoreAddons
import org.kde.kquickcontrolsaddons 2.0 as KQuickControlsAddons

import "lib"

Item {
	id: widget

	Logger {
		id: logger
		name: 'tiledmenu'
		// showDebug: true
	}

	SearchModel {
		id: search
		Component.onCompleted: {
			search.applyDefaultFilters()
		}
	}

	property alias rootModel: appsModel.rootModel
	AppsModel {
		id: appsModel
	}

	Item {
		// https://invent.kde.org/frameworks/kdeclarative/-/blob/master/src/qmlcontrols/kcoreaddons/kuserproxy.h
		// https://invent.kde.org/frameworks/kdeclarative/-/blob/master/src/qmlcontrols/kcoreaddons/kuserproxy.cpp
		KCoreAddons.KUser {
			id: kuser
			// faceIconUrl is an empty QUrl 'object' when ~/.face.icon doesn't exist.
			// Cast it to string first before checking if it's empty by casting to bool.
			readonly property bool hasFaceIcon: (''+faceIconUrl)
		}
		
		Kicker.SystemSettings {
			id: systemSettings
		}

		Kicker.DragHelper {
			id: dragHelper

			dragIconSize: PlasmaCore.Units.iconSizes.medium

			// Used when we only have a string and don't have a QIcon.
			// DragHelper.startDrag(...) requires a QIcon. See Issue #75.
			property var defaultIconItem: KQuickControlsAddons.QIconItem {
				id: defaultIconItem
			}
			property alias defaultIcon: defaultIconItem.icon
		}

		Kicker.ProcessRunner {
			id: processRunner
			// .runMenuEditor() to run kmenuedit
		}

		Kicker.WindowSystem {
			id: windowSystem
		}

		PlasmaCore.DataSource {
			id: executable
			engine: "executable"
			connectedSources: []
			onNewData: disconnectSource(sourceName) // cmd finished
			function exec(cmd) {
				connectSource(cmd)
			}
		}
	}

	AppletConfig {
		id: config
	}

	function logListModel(label, listModel) {
		console.log(label + '.count', listModel.count);
		// logObj(label, listModel);
		for (var i = 0; i < listModel.count; i++) {
			var item = listModel.modelForRow(i);
			var itemLabel = label + '[' + i + ']';
			console.log(itemLabel, item);
			logObj(itemLabel, item);
			if (('' + item).indexOf('Model') >= 0) {
				logListModel(itemLabel, item);
			}
		}
	}
	function logObj(label, obj) {
		// if (obj && typeof obj === 'object') {
		//  console.log(label, Object.keys(obj))
		// }
		
		for (var key in obj) {
			var val = obj[key];
			if (typeof val !== 'function') {
				var itemLabel = label + '.' + key;
				console.log(itemLabel, typeof val, val);
				if (('' + val).indexOf('Model') >= 0) {
					logListModel(itemLabel, val);
				}
			}
		}
	}

	Plasmoid.toolTipMainText: ""
	Plasmoid.toolTipSubText: ""

	Plasmoid.compactRepresentation: LauncherIcon {
		id: panelItem
		iconSource: plasmoid.configuration.icon || "start-here-kde"
	}

	Plasmoid.hideOnWindowDeactivate: !plasmoid.userConfiguring
	property bool expanded: plasmoid.expanded
	onExpandedChanged: {
		if (expanded) {
			search.query = ""
			search.applyDefaultFilters()
			config.showSearch = false
			popup.searchView.searchField.forceActiveFocus()
			popup.searchView.showDefaultView()
			// popup.searchView.tileEditorView.open('preferred://browser')
		}
	}

	// property alias searchResultsView: popup.searchView.searchResultsView
	// width: popup.width
	// height: popup.height
	Popup {
		id: popup
		anchors.fill: parent
	}
	Layout.minimumWidth: config.leftSectionWidth
	Layout.minimumHeight: config.minimumHeight
	Layout.preferredWidth: config.popupWidth
	Layout.preferredHeight: config.popupHeight

	// Layout.minimumHeight: 600 // For quickly testing as a desktop widget
	// Layout.minimumWidth: 800

	onWidthChanged: {
		// console.log('popup.size', width, height, 'width')
		resizeToFit.run()
	}
	onHeightChanged: {
		// console.log('popup.size', width, height, 'height')
		resizeHeight.restart()
	}

	Timer {
		id: resizeHeight
		interval: 200
		onTriggered: {
			if (!plasmoid.configuration.fullscreen) {
				// Need to Math.ceil when writing to fix (Issue #71)
				var dPR = PlasmaCore.Units.devicePixelRatio
				var pH2 = height / dPR
				var pH3 = Math.ceil(pH2)
				// console.log('pH.set', 'dPR='+dPR, 'pH1='+height, 'pH2='+pH2, 'pH3='+pH3)
				if (plasmoid.configuration.popupHeight != pH3) {
					plasmoid.configuration.popupHeight = pH3
				}
			}
		}
	}
	Timer {
		id: resizeToFit
		interval: attemptsLeft == attempts ? 200 : 100
		repeat: attemptsLeft > 0
		property int attempts: 10
		property int attemptsLeft: 10

		function run() {
			restart()
			attemptsLeft = attempts
		}

		onTriggered: {
			if (plasmoid.configuration.fullscreen) {
				attemptsLeft = 0
			} else {
				var favWidth = Math.max(0, widget.width - config.leftSectionWidth) // 398 // 888-60-430
				// console.log(favWidth, widget.width, config.leftSectionWidth)
				// console.log(favWidth / config.cellBoxSize)
				// var cols = Math.floor(favWidth / config.favColWidth) * 2
				var cols = Math.floor(favWidth / config.cellBoxSize)
				if (plasmoid.configuration.favGridCols != cols) {
					// console.log(plasmoid.configuration.favGridCols, cols)
					plasmoid.configuration.favGridCols = cols
				}
				// Force a reflow since Meta+RightClick+Drag resizing doesn't really play nice with PlasmaCore.Dialog.
				config.popupWidthChanged()
				widget.Layout.preferredWidthChanged()
				attemptsLeft -= 1
			}
		}
	}
	// Layout.onPreferredWidthChanged: console.log('popup.size', width, height)
	// Layout.onPreferredHeightChanged: console.log('popup.size', width, height)


	onFocusChanged: {
		if (focus) {
			popup.searchView.searchField.forceActiveFocus()
		}
	}

	function action_wx_apps() { appsModel.launch('phoenix-wx-apps') }
	function action_wx_power() { appsModel.launch('phoenix-wx-power') }
	function action_wx_events() { appsModel.launch('phoenix-wx-events') }
	function action_wx_system() { appsModel.launch('org.kde.kinfocenter') }
	function action_wx_devices() { appsModel.launch('phoenix-wx-devices') }
	function action_wx_network() { appsModel.launch('phoenix-wx-network') }
	function action_wx_disks() { appsModel.launch('org.kde.partitionmanager') }
	function action_wx_admin() { appsModel.launch('systemsettings') }
	function action_wx_term() { appsModel.launch('org.kde.konsole') }
	function action_wx_termadmin() { appsModel.launch('phoenix-wx-terminal-admin') }
	function action_wx_tasks() { appsModel.launch('phoenix-taskmanager') }
	function action_wx_settings() { appsModel.launch('systemsettings') }
	function action_wx_explorer() { appsModel.launch('phoenix-explorer') }
	function action_wx_search() { appsModel.launch('phoenix-wx-run') }
	function action_wx_run() { appsModel.launch('phoenix-wx-run') }
	function action_wx_logout() { appsModel.launch('phoenix-wx-logout') }
	function action_wx_desktop() { appsModel.launch('phoenix-wx-desktop') }
	function action_wx_winapps() { appsModel.launch('phoenix-winapps') }
	function action_wx_update() { appsModel.launch('phoenix-update') }
	function action_menuedit() { processRunner.runMenuEditor(); }

	Component.onCompleted: {
		if (plasmoid.hasOwnProperty("activationTogglesExpanded")) {
			plasmoid.activationTogglesExpanded = true
		}
		plasmoid.setAction("wx_apps", "Aplicaciones instaladas", "plasmadiscover");
		plasmoid.setAction("wx_power", "Opciones de energía", "preferences-system-power-management");
		plasmoid.setAction("wx_events", "Visor de eventos", "utilities-log-viewer");
		plasmoid.setAction("wx_system", "Sistema", "hwinfo");
		plasmoid.setAction("wx_devices", "Administrador de dispositivos", "computer");
		plasmoid.setAction("wx_network", "Conexiones de red", "network-wired");
		plasmoid.setAction("wx_disks", "Administración de discos", "drive-harddisk");
		plasmoid.setAction("wx_admin", "Administración de equipos", "preferences-system");
		plasmoid.setAction("wx_term", "Terminal", "utilities-terminal");
		plasmoid.setAction("wx_termadmin", "Terminal (Administrador)", "utilities-terminal");
		plasmoid.setActionSeparator("phoenixSep10")
		plasmoid.setAction("wx_tasks", "Administrador de tareas", "utilities-system-monitor");
		plasmoid.setAction("wx_settings", "Configuración", "preferences-system");
		plasmoid.setAction("wx_explorer", "Explorador de archivos", "system-file-manager");
		plasmoid.setAction("wx_search", "Buscar", "search");
		plasmoid.setAction("wx_run", "Ejecutar", "system-run");
		plasmoid.setActionSeparator("phoenixSep16")
		plasmoid.setAction("wx_logout", "Apagar o cerrar sesión", "system-shutdown");
		plasmoid.setAction("wx_desktop", "Escritorio", "user-desktop");
		plasmoid.setActionSeparator("phoenixSep19")
		plasmoid.setAction("wx_winapps", "Programas de Windows (Wine)", "wine");
		plasmoid.setAction("wx_update", "Actualizaciones", "system-software-update");
		plasmoid.setAction("menuedit", "Editar el menú Inicio (Linux)", "kmenuedit");

		// plasmoid.action('configure').trigger() // Uncomment to open the config window on load.
	}
}
