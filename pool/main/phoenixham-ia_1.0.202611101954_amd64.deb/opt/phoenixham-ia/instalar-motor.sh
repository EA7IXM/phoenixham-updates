#!/bin/sh
# Instala el motor de la IA (Ollama) en PhoenixHam OS. Lo lanza la app con la contraseña del usuario.
set -e
if ! command -v ollama >/dev/null 2>&1; then
  curl -fsSL https://ollama.com/install.sh | sh
fi
systemctl enable --now ollama >/dev/null 2>&1 || true
exit 0
