# Motor de voz de EA7IXM IA Hack.
# Recibe peticiones JSON por stdin (una por línea) y responde JSON por stdout:
#   {"id":1,"cmd":"stt","wav":"<base64>"}               -> {"id":1,"ok":true,"text":"..."}
#   {"id":2,"cmd":"tts","text":"...","voice":"...","rate":"+0%"} -> {"id":2,"ok":true,"audio":"<base64 mp3>"}
#   {"id":3,"cmd":"warm"}                                -> carga el oído por adelantado
# Oído: faster-whisper large-v3-turbo en la GPU (0,3 s); si no hay GPU libre, "small" en CPU.
# Voz: edge-tts (voces neuronales de Microsoft). Las frases se sintetizan EN PARALELO.
import sys, json, base64, os, glob, site, tempfile, asyncio, traceback, threading
from concurrent.futures import ThreadPoolExecutor

sys.stdout.reconfigure(encoding="utf-8")

# librerías CUDA instaladas con pip (nvidia-cublas-cu12, nvidia-cudnn-cu12)
for sp in site.getsitepackages() + [site.getusersitepackages()]:
    for d in glob.glob(os.path.join(sp, "nvidia", "*", "bin")):
        try:
            os.add_dll_directory(d)
        except OSError:
            pass
        os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")

PROMPT = ("Conversación en español de España con un asistente de inteligencia artificial. "
          "Radioafición, indicativos, bandas, propagación, Chrome, Windows, archivos, carpetas.")
_model = None
_engine = ""
_lock = threading.Lock()
out_lock = threading.Lock()


def model():
    global _model, _engine
    with _lock:
        if _model is None:
            from faster_whisper import WhisperModel
            try:
                m = WhisperModel("large-v3-turbo", device="cuda", compute_type="int8_float16")
                _model, _engine = m, "GPU · large-v3-turbo"
            except Exception:
                _model = WhisperModel("small", device="cpu", compute_type="int8",
                                      cpu_threads=max(4, (os.cpu_count() or 8) // 2))
                _engine = "CPU · small"
        return _model


def stt(wav_b64):
    fd, path = tempfile.mkstemp(suffix=".wav")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(base64.b64decode(wav_b64))
        m = model()
        with _lock:
            segs, _info = m.transcribe(path, language="es", beam_size=5, vad_filter=True,
                                       condition_on_previous_text=False, initial_prompt=PROMPT)
            segs = list(segs)
        # descartar trozos que Whisper "se inventa" con ruido de fondo
        good = [s.text for s in segs if not (s.no_speech_prob > 0.6 and s.avg_logprob < -0.8)]
        return "".join(good).strip()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


async def _tts(text, voice, rate, pitch):
    import edge_tts
    buf = bytearray()
    async for chunk in edge_tts.Communicate(text, voice, rate=rate, pitch=pitch or "+0Hz").stream():
        if chunk.get("type") == "audio":
            buf.extend(chunk["data"])
    return bytes(buf)


# ---- voz neuronal LOCAL (Kokoro, sin internet) ----
KOKORO_URL = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"
KOKORO_FILES = ("kokoro-v1.0.onnx", "voices-v1.0.bin")
_kokoro = None
_klock = threading.Lock()


def kokoro_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    cands = [os.environ.get("HACK_VOZ_DIR", ""), os.path.join(here, "voz"),
             os.path.join(here, "..", "..", "..", "voz"), "E:/QwenChat/voz",
             os.path.join(os.environ.get("LOCALAPPDATA", here), "EA7IXM-IA-Hack", "voz")]
    for d in cands:
        if d and all(os.path.isfile(os.path.join(d, f)) for f in KOKORO_FILES):
            return d
    # no está: descargarlo una vez (~350 MB)
    d = cands[-1]
    os.makedirs(d, exist_ok=True)
    import urllib.request
    for f in KOKORO_FILES:
        dst = os.path.join(d, f)
        if not os.path.isfile(dst):
            urllib.request.urlretrieve(KOKORO_URL + f, dst + ".part")
            os.replace(dst + ".part", dst)
    return d


def kokoro():
    global _kokoro
    with _klock:
        if _kokoro is None:
            from kokoro_onnx import Kokoro
            d = kokoro_dir()
            _kokoro = Kokoro(os.path.join(d, KOKORO_FILES[0]), os.path.join(d, KOKORO_FILES[1]))
        return _kokoro


def _tts_local(text, voice, rate):
    import io, soundfile as sf
    k = kokoro()
    try:
        speed = 1 + int(str(rate).replace("%", "")) / 100
    except ValueError:
        speed = 1.0
    with _klock:   # de una en una: así la 1ª frase sale antes
        a, sr = k.create(text, voice=voice, speed=max(0.6, min(1.6, speed)), lang="es")
    b = io.BytesIO()
    sf.write(b, a, sr, format="WAV", subtype="PCM_16")
    return b.getvalue()


def tts_any(text, voice, rate, pitch):
    """Voz local si se pide (local:xxx); si una falla, prueba con la otra para no quedarse mudo."""
    if voice.startswith("local:"):
        try:
            return _tts_local(text, voice[6:], rate)
        except Exception:
            return asyncio.run(_tts(text, "en-US-AndrewMultilingualNeural", rate, pitch))
    try:
        audio = asyncio.run(_tts(text, voice, rate, pitch))
        if audio:
            return audio
    except Exception:
        pass
    return _tts_local(text, "em_alex", rate)


def send(obj):
    with out_lock:
        sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
        sys.stdout.flush()


def handle(req):
    rid = req.get("id")
    try:
        cmd = req.get("cmd")
        if cmd == "stt":
            send({"id": rid, "ok": True, "text": stt(req["wav"])})
        elif cmd == "tts":
            audio = tts_any(req["text"], req.get("voice") or "local:bm_george", req.get("rate") or "+0%", req.get("pitch"))
            send({"id": rid, "ok": True, "audio": base64.b64encode(audio).decode("ascii")})
        elif cmd == "warm":
            model()
            eng = _engine
            try:
                kokoro()
                eng += " · voz local"
            except Exception:
                eng += " · voz online"
            send({"id": rid, "ok": True, "engine": eng})
        else:
            send({"id": rid, "ok": False, "error": "orden desconocida: %s" % cmd})
    except Exception as e:  # nunca morir por una petición mala
        send({"id": rid, "ok": False, "error": str(e) or e.__class__.__name__,
              "trace": traceback.format_exc()[-800:]})


pool = ThreadPoolExecutor(max_workers=6)
send({"id": 0, "ok": True, "ready": True})
for raw in sys.stdin.buffer:
    line = raw.decode("utf-8", "replace").strip()
    if not line:
        continue
    try:
        req = json.loads(line)
        # la voz (edge-tts) va en paralelo; el oído (GPU) en el hilo principal, que es más estable con CUDA
        if req.get("cmd") == "tts":
            pool.submit(handle, req)
        else:
            handle(req)
    except Exception as e:
        send({"id": None, "ok": False, "error": str(e)})
