#!/bin/sh
# Borra las descargas a medias de Ollama (pueden quedar dañadas tras un apagado brusco) y reinicia el motor.
systemctl stop ollama >/dev/null 2>&1 || true
for d in /usr/share/ollama/.ollama/models/blobs /root/.ollama/models/blobs; do
  [ -d "$d" ] && find "$d" -maxdepth 1 -name 'sha256-*-partial*' -delete
done
systemctl start ollama >/dev/null 2>&1 || true
sleep 2
exit 0
