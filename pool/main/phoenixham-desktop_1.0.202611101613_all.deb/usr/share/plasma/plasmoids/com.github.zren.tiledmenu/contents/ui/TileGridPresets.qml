import QtQuick 2.0
import org.kde.plasma.components 2.0 as PlasmaComponents

PlasmaComponents.MenuItem {
	id: presetMenuItem
	icon: "list-add-symbolic"
	text: i18n("Add Preset")

	//---
	// PhoenixHam OS: mosaicos de serie como el menú Inicio de Windows 10
	function addDefault() {
		var grupos = [
			["PhoenixHam", ["phoenix-winapps.desktop", "firefox.desktop", "phoenix-explorer.desktop",
			                "phoenix-store.desktop", "phoenix-update.desktop", "phoenix-controlpanel.desktop"]],
			["Oficina", ["libreoffice-writer.desktop", "libreoffice-calc.desktop", "libreoffice-impress.desktop",
			             "phoenix-notepad.desktop", "phoenix-rdp.desktop", "phoenix-equipo.desktop"]],
			["Radioaficionado", ["wsjtx.desktop", "js8call.desktop", "fldigi.desktop",
			                     "flrig.desktop", "cqrlog.desktop", "gpredict.desktop"]],
		]
		var y = tileGrid.findOpenPos(6, 1).y
		for (var g = 0; g < grupos.length; g++) {
			tileGrid.addGroup(0, y, { label: grupos[g][0], w: 6 })
			y += 1
			var n = 0
			for (var i = 0; i < grupos[g][1].length; i++) {
				var url = grupos[g][1][i]
				if (!isAppInstalled(url)) continue
				tileGrid.addTile((n % 3) * 2, y + Math.floor(n / 3) * 2, { url: url, w: 2, h: 2, showIcon: true, showLabel: true })
				n++
			}
			y += Math.ceil(n / 3) * 2
		}
	}

	function isAppInstalled(appId) {
		return appsModel.allAppsModel.hasApp(appId)
	}

	function addTilePreset(x, y, tileData) {
		var appId = tileData.url
		if (isAppInstalled(appId)) {
			return tileGrid.addTile(x, y, tileData)
		} else {
			return null
		}
	}

	function addGroupPreset(x, y, groupData, tileFnList) {
		var group = tileGrid.addGroup(x, y, groupData)
		var tileX = group.x
		var tileY = y + group.h
		for (var i = 0; i < tileFnList.length; i++) {
			var tileFn = tileFnList[i]
			var tile = tileFn(tileX, tileY)
			if (tile) {
				// TODO: Support Wrap
				tileX += tile.w
			}
		}
	}

	function addProductivity(x, y) {
		addGroupPreset(x, y, {
			label: i18n("Productivity"),
		}, [
			addWriter,
			addCalc,
			addMail,
		])
	}

	function addExplore(x, y) {
		addGroupPreset(x, y, {
			label: i18n("Explore"),
		}, [
			addAppCenter,
			addWebBrowser,
			addSteam,
		])
	}


	//---
	function addWriter(x, y) {
		return addTilePreset(x, y, {
			url: 'libreoffice-writer.desktop',
			backgroundColor: '#802584b7',
		})
	}
	function addCalc(x, y) {
		return addTilePreset(x, y, {
			url: 'libreoffice-calc.desktop',
			backgroundColor: '#80289769',
		})
	}
	function addMail(x, y) {
		var tile = addKMail(x, y)
		if (!tile) {
			tile = addGmail(x, y)
		}
		return tile
	}
	function addKMail(x, y) {
		return addTilePreset(x, y, {
			url: 'org.kde.kmail2.desktop',
		})
	}
	function addGmail(x, y) {
		return tileGrid.addTile(x, y, {
			url: 'https://mail.google.com/mail/u/0/#inbox',
			label: i18n("Gmail"),
			icon: 'mail-message',
			backgroundColor: '#80a73325',
		})
	}

	function addAppCenter(x, y) {
		if (isAppInstalled('octopi.desktop')) {
			return tileGrid.addTile(x, y, {
				url: 'octopi.desktop',
				label: i18n("Software Center"),
			})
		} else if (isAppInstalled('org.manjaro.pamac.manager.desktop')) {
			return tileGrid.addTile(x, y, {
				url: 'org.manjaro.pamac.manager.desktop',
				// default label is 'Add/Remove Software'
			})
		} else if (isAppInstalled('org.opensuse.yast.Packager.desktop')) {
			return tileGrid.addTile(x, y, {
				url: 'org.opensuse.yast.Packager.desktop',
				label: i18n("Software Center"),
			})
		} else if (isAppInstalled('org.kde.discover')) {
			return tileGrid.addTile(x, y, {
				url: 'org.kde.discover',
				label: i18n("Software Center"),
			})
		} else {
			return null
		}
	}

	function addWebBrowser(x, y) {
		return tileGrid.addTile(x, y, {
			url: 'preferred://browser',
		})
	}

	function addSteam(x, y) {
		return addTilePreset(x, y, {
			url: 'steam.desktop',
		})
	}


	//---
	PlasmaComponents.ContextMenu {
		visualParent: presetMenuItem.action

		PlasmaComponents.MenuItem {
			icon: "libreoffice-startcenter"
			text: i18n("Productivity")
			onClicked: {
				var pos = tileGrid.findOpenPos(6, 3)
				presetMenuItem.addProductivity(pos.x, pos.y)
			}
		}

		PlasmaComponents.MenuItem {
			icon: "internet-web-browser"
			text: i18n("Explore")
			onClicked: {
				var pos = tileGrid.findOpenPos(6, 3)
				presetMenuItem.addExplore(pos.x, pos.y)
			}
		}

		PlasmaComponents.MenuItem {
			icon: "mail-message"
			text: i18n("Gmail")
			onClicked: {
				var tile = presetMenuItem.addGmail(cellContextMenu.cellX, cellContextMenu.cellY)
				tileGrid.editTile(tile)
			}
		}
	}
}
